﻿using LibraryDataBase.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase.Entities.NonAbstracts
{
    public class Student:BaseEntity
    {
        public string LastName { get; set; }
        public int Term {  get; set; }
        [ForeignKey(nameof(Group))]
        public int Id_Group { get; set; }
        public virtual Group Group { get; set; }
        public Student() { }
    }
}
