﻿using LibraryDataBase.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase.Entities.NonAbstracts
{
    public class Book:BaseEntity
    {
        public int Pages { get; set; }
        public int YearPress { get; set; }
        public string Comment { get; set; }
        public int Quantity { get; set; }
        [ForeignKey(nameof(Theme))]
        public int Id_Themes { get; set; }
        [ForeignKey(nameof(Category))]
        public int Id_Category { get; set; }
        [ForeignKey(nameof(Author))]
        public int Id_Author { get; set; }
        [ForeignKey(nameof(Press))]
        public int Id_Press { get; set; }
        public virtual Theme Theme { get; set; }
        public virtual Category Category { get; set; }
        public virtual Author Author { get; set; }
        public virtual Press Press { get; set; }
        public Book() { }
    }
}
