﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI.ViewModels.CreateViewModel
{
    internal class CreateStudentViewModel : INotifyPropertyChanged
    {
        private string _name;
        private string _surname;
        private int _term;
        private int _groupId;
        public string Name { get { return _name; } set { _name = value; OnPropertyChanged(); } }
        public string Surname { get { return _surname; } set { _surname = value; OnPropertyChanged(); } }
        public int Term { get => _term; set { _term = value; OnPropertyChanged(); } }
        public int GroupId { get => _groupId; set { _groupId = value; OnPropertyChanged(); } }
        public MyRelayCommand CreateStudent { get; set; }

        public CreateStudentViewModel()
        {
            CreateStudent = new MyRelayCommand(studentExec);
        }

        public void studentExec(object param)
        {
            var data = new Student();
            data.Name = Name;
            data.LastName = Surname;
            data.Term = Term;
            data.Id_Group = GroupId;
            App._container.GetInstance<LibraryContext>().Students.Add(data);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
