﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FluentAPI.MyCommands;

public class MyRelayCommand : ICommand
{
    event EventHandler? ICommand.CanExecuteChanged
    {
        add
        {
            CommandManager.RequerySuggested += value;
        }

        remove
        {
            CommandManager.RequerySuggested -= value;
        }
    }

    private readonly Predicate<object?>? _canExecute;
    private readonly Action<object?>? _execute;

    public MyRelayCommand(Action<object?> execute, Predicate<object?> canExecute = null)
    {
        _canExecute = canExecute;
        _execute = execute;
    }

    bool ICommand.CanExecute(object? parameter)
    {
        if (_canExecute == null) return true;

        return _canExecute.Invoke(parameter);
    }

    void ICommand.Execute(object? parameter)
    {
        _execute.Invoke(parameter);
    }
}

