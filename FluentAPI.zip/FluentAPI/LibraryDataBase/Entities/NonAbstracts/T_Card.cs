﻿using LibraryDataBase.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase.Entities.NonAbstracts
{
    public class T_Card : BaseEntity
    {
        public DateTime DateOut { get; set; }
        public DateTime? DateIn { get; set; }
        [ForeignKey(nameof(Teacher))]
        public int Id_Teacher { get; set; }
        [ForeignKey(nameof(Book))]
        public int Id_Book { get; set; }
        [ForeignKey(nameof(Lib))]
        public int Id_Lib { get; set; }
        public virtual Teacher Teacher { get; set; }
        public virtual Book Book { get; set; }
        public virtual Lib Lib { get; set; }
        public T_Card()
        {
            DateOut = DateTime.Now;
        }
    }
}
