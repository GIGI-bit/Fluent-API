﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI.ViewModels.CreateViewModel
{
    internal class CreateTSCardViewModel : INotifyPropertyChanged
    {
        private int _id;
        private int _bookId;
        private int _libId;
        private DateTime _dateOut;
        private DateTime _dateIn;
        public int Id { get { return _id; } set { _id = value; OnPropertyChanged(); } }
        public int BookId { get { return _bookId; } set { _bookId = value; OnPropertyChanged(); } }
        public int LibId { get => _libId; set { _libId = value; OnPropertyChanged(); } }
        public DateTime DateOut { get => _dateOut; set { _dateOut = value; OnPropertyChanged(); } }
        public DateTime DateIn { get => _dateIn; set { _dateIn = value; OnPropertyChanged(); } }

        public MyRelayCommand CreateTCard { get; set; }
        public MyRelayCommand CreateSCard { get; set; }

        public CreateTSCardViewModel()
        {
            CreateTCard = new MyRelayCommand(TCard);
            CreateSCard = new MyRelayCommand(SCard);
        }

        public void TCard(object param)
        {
            var data = new T_Card();
            data.Id_Teacher = Id;
            data.Id_Lib = LibId;
            data.Id_Book = BookId;
            data.DateIn = DateIn;
            data.DateOut = DateOut;
            App._container.GetInstance<LibraryContext>().T_Card.Add(data);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }

        public void SCard(object param)
        {
            var data = new S_Card();
            data.Id_Student = Id;
            data.Id_Lib = LibId;
            data.Id_Book = BookId;
            data.DateIn = DateIn;
            data.DateOut = DateOut;
            App._container.GetInstance<LibraryContext>().S_Card.Add(data);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
