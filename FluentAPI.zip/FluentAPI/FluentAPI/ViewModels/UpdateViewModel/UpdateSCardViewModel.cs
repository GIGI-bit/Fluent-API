﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluentAPI.ViewModels.UpdateViewModel
{
    internal class UpdateSCardViewModel:INotifyPropertyChanged
    {
        private int _id;
        private int _sid;
        private int _bookId;
        private int _libId;
        private DateTime _dateOut;
        private DateTime _dateIn;
        private S_Card card;
        public int Id { get { return _id; } set { _id = value; OnPropertyChanged(); } }
        public int SId { get { return _sid; } set { _sid = value; OnPropertyChanged(); } }
        public int BookId { get { return _bookId; } set { _bookId = value; OnPropertyChanged(); } }
        public int LibId { get => _libId; set { _libId = value; OnPropertyChanged(); } }
        public DateTime DateOut { get => _dateOut; set { _dateOut = value; OnPropertyChanged(); } }
        public DateTime? DateIn { get => _dateIn; set { _dateIn = (DateTime)value; OnPropertyChanged(); } }

        public MyRelayCommand UpdateScard {  get; set; }
        public MyRelayCommand Search {  get; set; }

        public UpdateSCardViewModel()
        {
            UpdateScard = new MyRelayCommand(scardExec);
            Search = new MyRelayCommand(searchExe);
        }

        private void searchExe(object? obj)
        {
            card = App._container.GetInstance<LibraryContext>().S_Card.FirstOrDefault(card => card.Id == Id);
            if (card == null) MessageBox.Show("This S_Card does NOT exist!"); return;
            SId = card.Id_Student;
            BookId = card.Id_Book;
            LibId = card.Id_Lib;
            DateOut = card.DateOut;
            DateIn = card.DateIn;
        }

        private void scardExec(object? obj)
        {
            card.Id_Lib = LibId;
            card.Id_Book = BookId;
            card.DateOut = DateOut;
            card.DateIn = DateIn;
            card.Id_Student = SId;
            App._container.GetInstance<LibraryContext>().S_Card.Update(card);
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
