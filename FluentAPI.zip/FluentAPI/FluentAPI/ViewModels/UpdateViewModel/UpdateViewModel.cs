﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluentAPI.ViewModels.UpdateViewModel
{
    internal class UpdateViewModel : INotifyPropertyChanged
    {
        private int _id;
        private string _name;
        private List<string> _tables;
        private Faculty faculty;
        private Press press;
        private Theme theme;
        private int _index;
        public int Id { get { return _id; } set { _id = value;OnPropertyChanged(); } }
        public string Name { get { return _name; } set {_name=value; OnPropertyChanged(); } }
        public MyRelayCommand CreateFaculty {  get; set; }
        public MyRelayCommand CreatePress { get; set; }
        public MyRelayCommand CreateTheme { get; set; }
        public MyRelayCommand Search { get; set; }
        public List<string> Tables { get=>_tables; set { _tables = value;OnPropertyChanged(); } }
       public int Index { get => _index;set { _index = value;OnPropertyChanged(); } }

        public UpdateViewModel()
        {
            Tables = new List<string>() { "", "Faculty", "Press", "Theme" };
            CreateFaculty = new MyRelayCommand(facultyExec);
            CreatePress = new MyRelayCommand(pressExec);
            CreateTheme = new MyRelayCommand(themeExec);
            Search = new MyRelayCommand(searchExec);
        }

        private void searchExec(object? obj)
        {
            if (Index == 1) faculty = App._container.GetInstance<LibraryContext>().Faculties.FirstOrDefault(x => x.Id == Id);
            else if (Index == 2) press = App._container.GetInstance<LibraryContext>().Press.FirstOrDefault(x => x.Id == Id);
            else if (Index == 3) theme = App._container.GetInstance<LibraryContext>().Themes.FirstOrDefault(x => x.Id == Id);
        }

        private void themeExec(object? obj)
        {
            if (theme is null) MessageBox.Show("This Theme was NOT found!");
            else
            {
                theme.Name = Name;
                App._container.GetInstance<LibraryContext>().Themes.Update(theme);
                App._container.GetInstance<LibraryContext>().SaveChanges();
            }
        }

        private void pressExec(object? obj)
        {
            if (press is null) MessageBox.Show("This Press was NOT found!");
            else
            {
                press.Name = Name;
                App._container.GetInstance<LibraryContext>().Press.Update(press);
                App._container.GetInstance<LibraryContext>().SaveChanges();
            }
        }

        private void facultyExec(object? obj)
        {
            if (faculty is null) MessageBox.Show("This Faculty was NOT found!");
            else
            {
                faculty.Name = Name;
                App._container.GetInstance<LibraryContext>().Faculties.Update(faculty);
                App._container.GetInstance<LibraryContext>().SaveChanges();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
