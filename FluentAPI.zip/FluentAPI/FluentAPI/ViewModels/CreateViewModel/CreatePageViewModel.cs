﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI.ViewModels.CreateViewModel
{
    internal class CreatePageViewModel : INotifyPropertyChanged
    {
        private string _name;
        public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
        public MyRelayCommand CreateFaculty { get; set; }
        public MyRelayCommand CreatePress { get; set; }
        public MyRelayCommand CreateTheme { get; set; }
        public CreatePageViewModel()
        {
            CreateFaculty = new MyRelayCommand(facultyExec);
            CreatePress = new MyRelayCommand(pressExec);
            CreateTheme = new MyRelayCommand(themeExec);
        }

        public void facultyExec(object param)
        {
            var faculty = new Faculty();
            faculty.Name = Name;
            App._container.GetInstance<LibraryContext>().Faculties.Add(faculty);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }
        public void pressExec(object param)
        {
            var press = new Press();
            press.Name = Name;
            App._container.GetInstance<LibraryContext>().Press.Add(press);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }
        public void themeExec(object param)
        {
            var theme = new Theme();
            theme.Name = Name;
            App._container.GetInstance<LibraryContext>().Themes.Add(theme);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
