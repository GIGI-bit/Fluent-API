﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI.ViewModels.CreateViewModel
{
    internal class CreateALViewModel : INotifyPropertyChanged
    {
        private string _name;
        private string _surname;
        public string Name { get { return _name; } set { _name = value; OnPropertyChanged(); } }
        public string Surname { get { return _surname; } set { _surname = value; OnPropertyChanged(); } }
        public MyRelayCommand CreateAut { get; set; }
        public MyRelayCommand CreateLib { get; set; }
        public CreateALViewModel()
        {
            CreateAut = new MyRelayCommand(autExec);
            CreateLib = new MyRelayCommand(libExec);
        }

        private void autExec(object param)
        {
            var aut = new Author();
            aut.Name = Name;
            aut.LastName = Surname;
            App._container.GetInstance<LibraryContext>().Authors.Add(aut);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }
        private void libExec(object param)
        {
            var lib = new Lib();
            lib.Name = Name;
            lib.LastName = Surname;
            App._container.GetInstance<LibraryContext>().Libs.Add(lib);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
