﻿using LibraryDataBase.Entities.NonAbstracts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase
{
    public class LibraryContext:DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connection = "Data Source=DESKTOP-9FM91S3\\SQLEXPRESS;Initial Catalog=MyLibray;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;";
            optionsBuilder.UseLazyLoadingProxies()
                .UseSqlServer(connection);
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
            base.OnModelCreating(modelBuilder);
        }
        public override int SaveChanges()
        {
            
            return base.SaveChanges();
        }
        public DbSet<Student> Students { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Lib> Libs { get; set; }
        public DbSet<Theme> Themes { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<S_Card> S_Card { get; set; }      
        public DbSet<T_Card> T_Card { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Press> Press { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Faculty> Faculties { get; set;}
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Group> Groups { get; set; }

    }
}
