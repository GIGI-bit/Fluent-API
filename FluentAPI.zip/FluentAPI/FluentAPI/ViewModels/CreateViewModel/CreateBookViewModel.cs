﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI.ViewModels.CreateViewModel
{
    internal class CreateBookViewModel : INotifyPropertyChanged
    {
        private string _name;
        private string _comment;
        private int _page;
        private int _quantity;
        private int _yearPress;
        private int _themId;
        private int _cateId;
        private int _autId;
        private int _pressId;

        public int Pages { get => _page; set { _page = value; OnPropertyChanged(); } }
        public int Quantity { get => _quantity; set { _quantity = value; OnPropertyChanged(); } }
        public int YearPress { get => _yearPress; set { _yearPress = value; OnPropertyChanged(); } }
        public int ThemeId { get => _themId; set { _themId = value; OnPropertyChanged(); } }
        public int CategoryId { get => _cateId; set { _cateId = value; OnPropertyChanged(); } }
        public int AuthorId { get => _autId; set { _autId = value; OnPropertyChanged(); } }
        public int PressId { get => _pressId; set { _pressId = value; OnPropertyChanged(); } }
        public string Comment { get => _comment; set { _comment = value; OnPropertyChanged(); } }
        public string Name { get { return _name; } set { _name = value; OnPropertyChanged(); } }
        public MyRelayCommand CreateBook { get; set; }
        public CreateBookViewModel()
        {

        }
        private void bookExec(object param)
        {
            var book = new Book();
            book.Name = Name;
            book.YearPress = YearPress;
            book.Id_Press = PressId;
            book.Quantity = Quantity;
            book.Id_Author = AuthorId;
            book.Id_Category = CategoryId;
            book.Id_Themes = ThemeId;
            book.Comment = Comment;
            book.Pages = Pages;
            App._container.GetInstance<LibraryContext>().Books.Add(book);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
