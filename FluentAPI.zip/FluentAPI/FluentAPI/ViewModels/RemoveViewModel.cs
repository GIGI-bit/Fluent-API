﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI.ViewModels
{
    internal class RemoveViewModel:INotifyPropertyChanged
    {
        private int _id;
        public int Id { get { return _id; } set { _id = value;OnPropertyChanged(); } }
        public MyRelayCommand Remove {  get; set; }
        public RemoveViewModel(int selectedId)
        {
            Id= selectedId;
            Remove = new MyRelayCommand(removeExec);
        }

        private void removeExec(object? obj)
        {
            var table= App._container.GetInstance<LibraryContext>();
            dynamic data;
            switch (Id)
            {
                case 1:
                   data = table.Authors.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 2:
                    data = table.Books.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 3:
                    data = table.Categories.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 4:
                    data = table.Departments.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 5:
                    data = table.Faculties.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 6:
                    data = table.Groups.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 7:
                    data = table.Libs.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 8:
                    data = table.Press.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 9:
                    data = table.S_Card.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 10:
                    data = table.Students.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 11:
                    data = table.T_Card.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 12:
                    data = table.Teachers.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                case 13:
                    data = table.Themes.FirstOrDefault(a => a.Id == Id);
                    table.Remove(data);
                    break;
                
            }

        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
