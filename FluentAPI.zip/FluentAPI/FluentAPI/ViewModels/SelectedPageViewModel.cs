﻿using LibraryDataBase;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace FluentAPI.ViewModels
{
    internal class SelectedPageViewModel : INotifyPropertyChanged
    {
        public dynamic tableData;
        public dynamic TableDatas {  get=>tableData; set { tableData = value; OnPropertyChanged(); } }
        
        private int SelectedIndex;
        public SelectedPageViewModel(int selectedndex)
        {
            SelectedIndex = selectedndex;
            GridFiller();
        }
        private void GridFiller()
        {
            
            switch(SelectedIndex)
            {
                case 1:
                    TableDatas = App._container.GetInstance<LibraryContext>().Authors.ToList();
                    break;
                case 2:
                    TableDatas = App._container.GetInstance<LibraryContext>().Books.ToList();
                    break;
                case 3:
                    TableDatas=App._container.GetInstance<LibraryContext>().Categories.ToList(); 
                    break;
                case 4:
                    TableDatas = App._container.GetInstance<LibraryContext>().Departments.ToList();
                    break;
                case 5:
                    TableDatas = App._container.GetInstance<LibraryContext>().Faculties.ToList();
                    break;
                case 6:
                    TableDatas = App._container.GetInstance<LibraryContext>().Groups.ToList();
                    break;
                case 7:
                    TableDatas = App._container.GetInstance<LibraryContext>().Libs.ToList();
                    break;
                case 8:
                    TableDatas = App._container.GetInstance<LibraryContext>().Press.ToList();
                    break;
                case 9:
                    TableDatas=App._container.GetInstance<LibraryContext>().S_Card.ToList();
                    break;
                case 10:
                    TableDatas= App._container.GetInstance<LibraryContext>().Students.ToList();
                    break;
                case 11:
                    TableDatas = App._container.GetInstance<LibraryContext>().T_Card.ToList();
                    break;
                case 12:
                    TableDatas= App._container.GetInstance<LibraryContext>().Teachers.ToList();
                    break;
                case 13:
                    TableDatas=App._container.GetInstance<LibraryContext>().Themes.ToList();
                    break;
            }
            
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
