﻿using FluentAPI.MyCommands;
using LibraryDataBase.Entities.NonAbstracts;
using LibraryDataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluentAPI.ViewModels.UpdateViewModel
{
    internal class UpdateTCardViewModel:INotifyPropertyChanged
    {
        private int _id;
        private int _tid;
        private int _bookId;
        private int _libId;
        private DateTime _dateOut;
        private DateTime _dateIn;
        private T_Card card;
        public int Id { get { return _id; } set { _id = value; OnPropertyChanged(); } }
        public int TId { get { return _tid; } set { _tid = value; OnPropertyChanged(); } }
        public int BookId { get { return _bookId; } set { _bookId = value; OnPropertyChanged(); } }
        public int LibId { get => _libId; set { _libId = value; OnPropertyChanged(); } }
        public DateTime DateOut { get => _dateOut; set { _dateOut = value; OnPropertyChanged(); } }
        public DateTime? DateIn { get => _dateIn; set { _dateIn = (DateTime)value; OnPropertyChanged(); } }

        public MyRelayCommand UpdateTcard { get; set; }
        public MyRelayCommand Search { get; set; }

        public UpdateTCardViewModel()
        {
            UpdateTcard = new MyRelayCommand(tcardExec);
            Search = new MyRelayCommand(searchExe);
        }

        private void searchExe(object? obj)
        {
            card = App._container.GetInstance<LibraryContext>().T_Card.FirstOrDefault(card => card.Id == Id);
            if (card == null) MessageBox.Show("This S_Card does NOT exist!"); return;
            TId = card.Id_Teacher;
            BookId = card.Id_Book;
            LibId = card.Id_Lib;
            DateOut = card.DateOut;
            DateIn = card.DateIn;
        }

        private void tcardExec(object? obj)
        {
            card.Id_Lib = LibId;
            card.Id_Book = BookId;
            card.DateOut = DateOut;
            card.DateIn = DateIn;
            card.Id_Teacher = TId;
            App._container.GetInstance<LibraryContext>().T_Card.Update(card);
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
