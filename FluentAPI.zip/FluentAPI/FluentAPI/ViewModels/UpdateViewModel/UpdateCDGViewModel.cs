﻿using FluentAPI.MyCommands;
using LibraryDataBase.Entities.NonAbstracts;
using LibraryDataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluentAPI.ViewModels.UpdateViewModel
{
    internal class UpdateCDGViewModel: INotifyPropertyChanged
    {
        private int _id;
        private string _name;
        private List<string> _tables;
        private Category category;
        private Department dep;
        private Group group;
        private int _index;
        public int Id { get { return _id; } set { _id = value; OnPropertyChanged(); } }
        public string Name { get { return _name; } set { _name = value; OnPropertyChanged(); } }
        public MyRelayCommand UpdateCategory { get; set; }
        public MyRelayCommand UpdateDepartment { get; set; }
        public MyRelayCommand UpdateGroup { get; set; }
        public MyRelayCommand Search { get; set; }
        public List<string> Tables { get => _tables; set { _tables = value; OnPropertyChanged(); } }
        public int Index { get => _index; set { _index = value; OnPropertyChanged(); } }

        public UpdateCDGViewModel()
        {
            Tables = new List<string>() { "", "Category", "Department", "Group" };
            UpdateCategory = new MyRelayCommand(catExec);
            UpdateDepartment = new MyRelayCommand(depExec);
            UpdateGroup = new MyRelayCommand(groupExec);
            Search = new MyRelayCommand(searchExec);
        }

        private void searchExec(object? obj)
        {
            if (Index == 1) category = App._container.GetInstance<LibraryContext>().Categories.FirstOrDefault(x => x.Id == Id);
            else if (Index == 2) dep = App._container.GetInstance<LibraryContext>().Departments.FirstOrDefault(x => x.Id == Id);
            else if (Index == 3) group = App._container.GetInstance<LibraryContext>().Groups.FirstOrDefault(x=>x.Id==Id);
        }

        private void groupExec(object? obj)
        {
            if (group is null) MessageBox.Show("This Group was NOT found!");
            else
            {
                group.Name = Name;
                App._container.GetInstance<LibraryContext>().Groups.Update(group);
                App._container.GetInstance<LibraryContext>().SaveChanges();
            }
        }

        private void depExec(object? obj)
        {
            if (dep is null) MessageBox.Show("This Department was NOT found!");
            else
            {
                dep.Name = Name;
                App._container.GetInstance<LibraryContext>().Departments.Update(dep);
                App._container.GetInstance<LibraryContext>().SaveChanges();
            }
        }

        private void catExec(object? obj)
        {
            if (category is null) MessageBox.Show("This Category was NOT found!");
            else
            {
                category.Name = Name;
                App._container.GetInstance<LibraryContext>().Categories.Update(category);
                App._container.GetInstance<LibraryContext>().SaveChanges();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
