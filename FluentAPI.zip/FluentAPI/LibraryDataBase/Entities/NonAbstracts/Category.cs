﻿using LibraryDataBase.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase.Entities.NonAbstracts
{
    public class Category:BaseEntity
    {
        public Category() { }
    }
}
