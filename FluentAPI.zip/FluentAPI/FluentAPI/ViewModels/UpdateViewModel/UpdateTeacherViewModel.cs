﻿using FluentAPI.MyCommands;
using LibraryDataBase.Entities.NonAbstracts;
using LibraryDataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluentAPI.ViewModels.UpdateViewModel
{
    internal class UpdateTeacherViewModel : INotifyPropertyChanged
    {
        private int _id;
        private string _name;
        private string _surname;
        private int _did;
        private Teacher teacher;
        public int Id { get { return _id; } set { _id = value; OnPropertyChanged(); } }
        public int DepId { get => _did; set { _did = value; OnPropertyChanged(); } }
        public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
        public string Surname { get => _surname; set { _surname = value; OnPropertyChanged(); } }
        public MyRelayCommand Search { get; set; }
        public MyRelayCommand UpdateTeacher { get; set; }

        public UpdateTeacherViewModel()
        {
            Search = new MyRelayCommand(searchExec);
            UpdateTeacher= new MyRelayCommand(tecExec);
        }

        private void tecExec(object? obj)
        {
            teacher.Name = Name;
            teacher.LastName = Surname;
            teacher.Id_Dep = DepId;
            App._container.GetInstance<LibraryContext>().Teachers.Update(teacher);
        }

        private void searchExec(object? obj)
        {
            teacher = App._container.GetInstance<LibraryContext>().Teachers.FirstOrDefault(x => x.Id == Id);
            if (teacher == null) MessageBox.Show("Not Found"); return;
            Name = teacher.Name;
            Surname = teacher.LastName;
            DepId = teacher.Id_Dep;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}   
