﻿using LibraryDataBase.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase.Entities.NonAbstracts
{
    public class Teacher:BaseEntity
    {
        public string LastName { get; set; }
        [ForeignKey(nameof(Department))]
        public int Id_Dep {  get; set; }
        public virtual Department Department { get; set; }
        public Teacher()
        {
            
        }
    }
}
