﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluentAPI.ViewModels.UpdateViewModel
{
    internal class UpdateALViewModel : INotifyPropertyChanged
    {
        private int _id;
        private string _name;
        private string _surname;
        private int _index;
        private Author author;
        private Lib lib;
        private List<string> tables;
        public List<string> Tables;
        public int Id { get { return _id; } set { _id = value; OnPropertyChanged(); } }
        public string Name { get { return _name; } set { _name = value; OnPropertyChanged(); } }
        public string Surname { get { return _surname; } set { _surname = value; OnPropertyChanged(); } }
        public int Index { get => _index; set { _index = value; OnPropertyChanged(); } }
        public MyRelayCommand UpdateAut { get; set; }
        public MyRelayCommand UpdateLib { get; set; }
        public MyRelayCommand Search { get; set; }


        public UpdateALViewModel()
        {
            Tables = new List<string>() { "", "Author", "Lib" };
            UpdateAut = new MyRelayCommand(autExec);
            UpdateLib = new MyRelayCommand(libExec);
            Search = new MyRelayCommand(searExec);
        }

        private void searExec(object? obj)
        {
            if (Index == 1)
            {
                author = App._container.GetInstance<LibraryContext>().Authors.FirstOrDefault(x => x.Id == Id);
                if (author is null) MessageBox.Show("This Author was NOT found!"); return;
                Name = author.Name;
                Surname = author.LastName;
            }
            else if (Index == 2)
            {
                lib = App._container.GetInstance<LibraryContext>().Libs.FirstOrDefault(x => x.Id == Id);
                if (lib is null) MessageBox.Show("This Lib was NOT found!"); return;
                Name = lib.Name;
                Surname = lib.LastName;
            }
        }

        private void libExec(object? obj)
        {
            lib.Name = Name;
            lib.LastName = Surname;
            App._container.GetInstance<LibraryContext>().Libs.Update(lib);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }

        private void autExec(object? obj)
        {
            author.Name = Name;
            author.LastName = Surname;
            App._container.GetInstance<LibraryContext>().Authors.Update(author);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
