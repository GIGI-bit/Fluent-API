﻿using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;

LibraryContext _context=new();

var categories=new Category() { Name="Design"};
var categories2=new Category() { Name="Programming"};
var categories3=new Category() { Name="Economics"};
var categories4=new Category() { Name="Social Scienes"};
_context.Categories.Add(categories);
_context.Categories.Add(categories2);
_context.Categories.Add(categories3);
_context.Categories.Add(categories4);

var theme = new Theme() { Name = "Practical" };
var theme2 = new Theme() { Name = "Educational" };
var theme3 = new Theme() { Name = "Test" };
_context.Themes.Add(theme);
_context.Themes.Add(theme2);
_context.Themes.Add(theme3);

var press = new Press() { Name = "New Baku" };
var press2 = new Press() { Name = "NPA" };//National Press of Azerbaijan
var press3 = new Press() { Name = "TQDK" };

_context.Press.Add(press);
_context.Press.Add(press2);
_context.Press.Add(press3);

var author = new Author() { Name = "Jay", LastName = "Robert" };
var author2 = new Author() { Name = "Murad", LastName = "Hesenli" };
var author3 = new Author() { Name = "Ayten", LastName = "Melikova" };
var author4 = new Author() { Name = "Xanim", LastName = "Isayeva" };

_context.Authors.Add(author);
_context.Authors.Add(author2);
_context.Authors.Add(author3);
_context.Authors.Add(author4);

var book =new Book() { Name="How to design like a Pro", Id_Themes=2, Id_Author=1,Id_Category=1, Id_Press=1,YearPress=2013, Pages=381, Quantity=9};
var book2 =new Book() { Name="How to code like a Pro", Id_Themes=2, Id_Author=3,Id_Category=2, Id_Press=1,YearPress=2017, Pages=290, Quantity=3};
var book3 =new Book() { Name="Secrets of Economics", Id_Themes=2, Id_Author=2,Id_Category=3, Id_Press=2,YearPress=2023, Pages=211, Quantity=1};
var book4 =new Book() { Name="100 questions from Social Science", Id_Themes=3, Id_Author=4,Id_Category=4, Id_Press=1,YearPress=2020, Pages=120, Quantity=3};
var book5 =new Book() { Name="1000 tests from Math", Id_Themes=3, Id_Author=2,Id_Category=3, Id_Press=3,YearPress=2023, Pages=689, Quantity=7};

_context.Books.Add(book);
_context.Books.Add(book2);
_context.Books.Add(book3);
_context.Books.Add(book4);
_context.Books.Add(book5);

var facul = new Faculty() { Name = "3D Design" };
var facul2 = new Faculty() { Name = "Programming" };
var facul3 = new Faculty() { Name = "Accounting" };
var facul4 = new Faculty() { Name = "Philosophy" };

_context.Faculties.Add(facul);
_context.Faculties.Add(facul2);
_context.Faculties.Add(facul3);
_context.Faculties.Add(facul4);





