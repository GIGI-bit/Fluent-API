﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI.ViewModels.CreateViewModel
{
    internal class CreateTeacherViewModel : INotifyPropertyChanged
    {
        private string _name;
        private string _surname;
        private int _depId;
        public string Name { get { return _name; } set { _name = value; OnPropertyChanged(); } }
        public string Surname { get { return _surname; } set { _surname = value; OnPropertyChanged(); } }
        public int DepId { get { return _depId; } set { _depId = value; OnPropertyChanged(); } }
        public MyRelayCommand CreateTeacher { get; set; }

        public CreateTeacherViewModel()
        {
            CreateTeacher = new MyRelayCommand(teacherExec);
        }

        public void teacherExec(object param)
        {
            var data = new Teacher();
            data.Name = Name;
            data.LastName = Surname;
            data.Id_Dep = DepId;
            App._container.GetInstance<LibraryContext>().Teachers.Add(data);
            App._container.GetInstance<LibraryContext>().SaveChanges();
        }


        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
