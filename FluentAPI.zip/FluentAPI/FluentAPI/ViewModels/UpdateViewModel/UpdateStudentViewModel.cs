﻿using FluentAPI.MyCommands;
using LibraryDataBase;
using LibraryDataBase.Entities.NonAbstracts;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluentAPI.ViewModels.UpdateViewModel
{
    internal class UpdateStudentViewModel : INotifyPropertyChanged
    {
        private int _id;
        private int _term;
        private string _name;
        private string _surname;
        private int _gid;
        private Student student;
        public int Term { get => _term; set { _term = value; OnPropertyChanged(); } }
        public int Id { get { return _id; } set { _id = value; OnPropertyChanged(); } }
        public int GroupId { get => _gid; set { _gid = value; OnPropertyChanged(); } }
        public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
        public string Surname { get => _surname; set { _surname = value; OnPropertyChanged(); } }
        public MyRelayCommand Search { get; set; }
        public MyRelayCommand UpdateStudent {  get; set; }

        public UpdateStudentViewModel()
        {
            Search = new MyRelayCommand(searchExec);
            UpdateStudent = new MyRelayCommand(studExec);
        }

        private void studExec(object? obj)
        {
            student.Name = Name;
            student.LastName = Surname;
            student.Id_Group = GroupId;
            student.Term = Term;
            App._container.GetInstance<LibraryContext>().Students.Update(student);
        }

        private void searchExec(object? obj)
        {
            student = App._container.GetInstance<LibraryContext>().Students.FirstOrDefault(x => x.Id == Id);
            if (student == null) MessageBox.Show("Not Found");return;
            Name = student.Name;
            Surname = student.LastName;
            Term = student.Term;
            GroupId = student.Id_Group;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        
    }
}
