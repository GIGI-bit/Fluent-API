﻿using FluentAPI.MyCommands;
using LibraryDataBase.Entities.NonAbstracts;
using LibraryDataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI.ViewModels.CreateViewModel;

internal class CreateCDGViewModel : INotifyPropertyChanged
{
    private string _name;
    public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
    public MyRelayCommand CreateCategory { get; set; }
    public MyRelayCommand CreateDep { get; set; }
    public MyRelayCommand CreateGroup { get; set; }
    public CreateCDGViewModel()
    {
        CreateCategory = new MyRelayCommand(categoryExec);
        CreateDep = new MyRelayCommand(DepExec);
        CreateGroup = new MyRelayCommand(groupExec);
    }

    private void categoryExec(object param)
    {
        var data = new Category();
        data.Name = Name;
        App._container.GetInstance<LibraryContext>().Categories.Add(data);
        App._container.GetInstance<LibraryContext>().SaveChanges();
    }
    private void DepExec(object param)
    {
        var data = new Department();
        data.Name = Name;
        App._container.GetInstance<LibraryContext>().Departments.Add(data);
        App._container.GetInstance<LibraryContext>().SaveChanges();
    }
    private void groupExec(object param)
    {
        var data = new Group();
        data.Name = Name;
        App._container.GetInstance<LibraryContext>().Groups.Add(data);
        App._container.GetInstance<LibraryContext>().SaveChanges();
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
        if (PropertyChanged != null)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}


