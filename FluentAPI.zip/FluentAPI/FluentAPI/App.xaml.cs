﻿using FluentAPI.Pages;
using FluentAPI.Pages.UpdatePages;
using FluentAPI.ViewModels;
using FluentAPI.ViewModels.CreateViewModel;
using FluentAPI.ViewModels.UpdateViewModel;
using LibraryDataBase;
using SimpleInjector;
using System.Configuration;
using System.Data;
using System.Runtime.CompilerServices;
using System.Windows;

namespace FluentAPI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Container? _container;
        private void MainStart(object sender, StartupEventArgs e)
        {
            Register();
            var view = _container.GetInstance<MainWindow>();
            view.ShowDialog();
        }
        private void Register()
        {
            _container = new Container();
            _container.RegisterSingleton<LibraryContext>();
            _container.RegisterSingleton<CreatePage>();
            _container.RegisterSingleton<UpdatePage>();
            _container.RegisterSingleton<CreateCDG>();
            _container.RegisterSingleton<CreatePageViewModel>();
            _container.RegisterSingleton<MainViewModel>();
            _container.RegisterSingleton<MainWindow>();
            _container.RegisterSingleton<CreateCDGViewModel>();
            _container.RegisterSingleton<CreateAL>();
            _container.RegisterSingleton<CreateALViewModel>();
            _container.RegisterSingleton<CreateStudentView>();
            _container.RegisterSingleton<CreateStudentViewModel>();
            _container.RegisterSingleton<CreateTeacherView>();
            _container.RegisterSingleton<CreateTeacherViewModel>();
            _container.RegisterSingleton<CreateBookView>();
            _container.RegisterSingleton<CreateBookViewModel>();
            _container.RegisterSingleton<CreateTSCardView>();
            _container.RegisterSingleton<CreateTSCardViewModel>();
            _container.RegisterSingleton<UpdateViewModel>();
            _container.RegisterSingleton<UpdateCDG>();
            _container.RegisterSingleton<UpdateCDGViewModel>();
            _container.RegisterSingleton<UpdateAL>();
            _container.RegisterSingleton<UpdateALViewModel>();
            _container.RegisterSingleton<UpdateBookView>();
            _container.RegisterSingleton<UpdateBookViewModel>();
            _container.RegisterSingleton<UpdateSCardView>();
            _container.RegisterSingleton<UpdateSCardViewModel>();
            _container.RegisterSingleton<UpdateTCard>();
            _container.RegisterSingleton<UpdateTCardViewModel>();
            _container.RegisterSingleton<UpdateStudentView>();
            _container.RegisterSingleton<UpdateStudentViewModel>();
            _container.RegisterSingleton<UpdateTeacher>();
            _container.RegisterSingleton<UpdateTeacherViewModel>();
            _container.Verify();
        }
    }

}
