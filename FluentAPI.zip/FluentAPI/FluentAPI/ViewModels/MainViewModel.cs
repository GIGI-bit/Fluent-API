﻿using FluentAPI.MyCommands;
using FluentAPI.Pages;
using FluentAPI.Pages.UpdatePages;
using LibraryDataBase;
using LibraryDataBase.Entities.Abstracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Navigation;

namespace FluentAPI.ViewModels
{
    internal class MainViewModel : INotifyPropertyChanged
    {
        private int _selectedIndex;
        private ObservableCollection<string> _tableNames;
        public ObservableCollection<string> TableNames { get { return _tableNames; } set { _tableNames = value; } }
        public int SelectedIndex { get=> _selectedIndex; set { _selectedIndex = value; OnPropertyChanged(); } }
        
       public MyRelayCommand _Select_all {  get; set; }
        public MyRelayCommand _create_btn {  get; set; }
        public MyRelayCommand _remove_btn { get; set; }
        public MyRelayCommand _insert_btn { get; set; }
        public MyRelayCommand _update_btn { get; set; }

        public MainViewModel()
        {
            ComboboxFiller();
            _Select_all = new MyRelayCommand(SelectExec);
            _create_btn = new MyRelayCommand(CreateExecute);
            _remove_btn = new MyRelayCommand(RemoveExec);
            _update_btn = new MyRelayCommand(UpdateExec);
        }

        private void SelectExec(object? obj)
        {
            if (obj is Frame frame)
            {
                frame.Navigate(new SelectedPageView(SelectedIndex));
            }
        }

        public void CreateExecute(object param)
        {
            if(param is Frame frame)
            {
                if (SelectedIndex == 1 || SelectedIndex == 7) frame.Navigate(App._container.GetInstance<CreateAL>());
                else if(SelectedIndex==2) frame.Navigate(App._container.GetInstance<CreateBookView>());
                else if(SelectedIndex==3|| SelectedIndex == 4|| SelectedIndex == 6) frame.Navigate(App._container.GetInstance<CreateCDG>());
                else if(SelectedIndex==5|| SelectedIndex == 8|| SelectedIndex == 13) frame.Navigate(App._container.GetInstance<CreatePage>());
                else if(SelectedIndex==9|| SelectedIndex == 11) frame.Navigate(App._container.GetInstance<CreateTSCardView>());
                else if(SelectedIndex==12) frame.Navigate(App._container.GetInstance<CreateTeacherView>());
                else if(SelectedIndex == 10) frame.Navigate(App._container.GetInstance<CreateStudentView>());
            }
        }

        public void RemoveExec(object param)
        {
            if (param is Frame frame)
            {
                frame.Navigate(new RemovePage(SelectedIndex));
            }
        }

       

        public void UpdateExec(object param)
        {
            if (param is Frame frame)
            {
                if (SelectedIndex == 1 || SelectedIndex == 7) frame.Navigate(App._container.GetInstance<UpdateAL>());
                else if (SelectedIndex == 2) frame.Navigate(App._container.GetInstance<UpdateBookView>());
                else if (SelectedIndex == 3 || SelectedIndex == 4 || SelectedIndex == 6) frame.Navigate(App._container.GetInstance<UpdateCDG>());
                else if (SelectedIndex == 5 || SelectedIndex == 8 || SelectedIndex == 13) frame.Navigate(App._container.GetInstance<UpdatePage>());
                else if (SelectedIndex == 9 ) frame.Navigate(App._container.GetInstance<UpdateSCardView>());
                else if( SelectedIndex == 11) frame.Navigate(App._container.GetInstance<UpdateTCard>());
                else if (SelectedIndex == 12) frame.Navigate(App._container.GetInstance<UpdateTeacher>());
                else if (SelectedIndex == 10) frame.Navigate(App._container.GetInstance<UpdateStudentView>());
            }
        }
      
        private void ComboboxFiller()
        {
            
            TableNames = new ObservableCollection<string>() {" ","Authors", "Books", "Categories", "Departments", "Faculties", "Groups", "Libs", "Press", "S_Card", "T_Card", "Students", "Teachers", "Themes" };
        }
       

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
