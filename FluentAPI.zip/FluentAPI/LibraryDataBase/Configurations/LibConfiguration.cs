﻿using LibraryDataBase.Entities.NonAbstracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase.Configurations
{
    internal class LibConfiguration : IEntityTypeConfiguration<Lib>
    {
        public void Configure(EntityTypeBuilder<Lib> builder)
        {
            builder.HasKey(l => l.Id);
            builder.Property(l => l.Name).HasColumnName("FirstName").HasMaxLength(30);
            builder.Property(l=>l.LastName).HasMaxLength(30);
        }
    }
}
