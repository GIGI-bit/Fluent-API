﻿using LibraryDataBase.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase.Entities.NonAbstracts
{
    public class Group:BaseEntity
    {
        [ForeignKey(nameof(Faculty))]
        public int Id_Faculty { get; set; }
        public virtual Faculty Faculty { get; set; }
        public Group() { }
    }
}
