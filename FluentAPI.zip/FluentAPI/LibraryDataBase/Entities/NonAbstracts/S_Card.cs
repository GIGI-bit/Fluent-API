﻿using LibraryDataBase.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDataBase.Entities.NonAbstracts
{
    public class S_Card:BaseEntity
    {
        [ForeignKey(nameof(Student))]
        public int Id_Student { get; set; }
        [ForeignKey(nameof(Book))]
        public int Id_Book { get; set; }
        [ForeignKey(nameof(Lib))]
        public int Id_Lib {  get; set; }
        public  DateTime DateOut { get; set; }
        public  DateTime? DateIn { get; set; }
        public virtual Book Book { get; set; }
        public virtual Lib Lib { get; set; }
        public virtual Student Student { get; set; }

        public S_Card() { DateOut = DateTime.Now; }
    }
}
